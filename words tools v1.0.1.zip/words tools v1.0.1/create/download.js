var fs = require('fs');
var url = require('url');
var http = require('http');
var exec = require('child_process').exec;
var spawn = require('child_process').spawn;
var app = require("./app");

var file = fs.readFileSync("../fetching/audio.txt", { encoding: "utf8" }); // data to String.
file = file.replace(/(?:\r\n|\r|\n)/g, '\n');
var arr = file.split("\n"); // an array of every string in file.

var DOWNLOAD_DIR = '../audio/' + app.words_file + '/';
var fetching = "../fetching";
var audio = "../audio";
var result = "../result";



// Check if download dir is exist
if (!fs.existsSync(fetching)) {
    fs.mkdirSync(fetching);
}

if (!fs.existsSync(audio)) {
    fs.mkdirSync(audio);
}

if (!fs.existsSync(result)) {
    fs.mkdirSync(result);
}

if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR);
}
for (var i = 0; i < arr.length; i++) {
    var file_name = arr[i].substring(0, arr[i].indexOf("\t"))
    var file_url = arr[i].substring(arr[i].indexOf("\t") + 1)
    if ((file_name != "") && (file_url != "")) {
        file_name = DOWNLOAD_DIR + file_name + ".mp3"
        if (!fs.existsSync(file_name)) {
            download_file_curl(file_url, file_name)
        }
    }
}



// Function for downloading file using curl
function download_file_curl(file_url, file_name) {
    // extract the file name
    // create an instance of writable stream
    var file = fs.createWriteStream(file_name);
    // execute curl using child_process' spawn function
    var curl = spawn('curl', [file_url]);
    // add a 'data' event listener for the spawn instance
    curl.stdout.on('data', function(data) { file.write(data); });
    // add an 'end' event listener to close the writeable stream
    curl.stdout.on('end', function(data) {
        file.end();
        //console.log(file_name + ' downloaded to ' + DOWNLOAD_DIR);
    });
    // when the spawn child process exits, check if there were any errors and close the writeable stream
    curl.on('exit', function(code) {
        if (code != 0) {
            console.log('Failed: ' + code);
        }
    });
}
// End function download file